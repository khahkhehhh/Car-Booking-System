<?php
//Set Db parameters

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_cbs";

//Create DB Connection
$con = mysqli_connect($servername, $username, $password, $dbname);
//Create Db Connection



?>