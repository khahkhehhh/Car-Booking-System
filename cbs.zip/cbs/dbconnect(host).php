<?php
//Set Db parameters

$servername = "localhost";
$username = "id19762047_khahkheh";
$password = "Fongkheh2727@";
$dbname = "id19762047_db_cbs";

//Create DB Connection
$con = mysqli_connect($servername, $username, $password, $dbname);
//Create Db Connection



?>