

<div class="footer" style="background-color:darkblue;">
  <p>Copyright @2020 by KK Sdn.Bhd</p>
</div>


</body>
</html>
