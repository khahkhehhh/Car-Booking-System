<?php include 'headermain.php';?>



    <div class="hero-wrap ftco-degree-bg" style="background-image: url('img/bg_1.jpg') ;" >
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text justify-content-start align-items-center justify-content-center">
          <div class="col-lg-8 ftco-animate">
            <div class="text w-100 text-center mb-md-5 pb-md-5">
              <br><br><br><br>

              <h1 class="mb-4" style="color: white; font-size: 50px;">Fast &amp; Easy Way To Rent<br> A Car</h1>
              <p style="font-size: 18px;color: white;">A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts</p>


              <br><br><br><br><br><br>


              <a href="https://vimeo.com/45830194" class="icon-wrap popup-vimeo d-flex align-items-center mt-4 justify-content-center">
                <div class="icon d-flex align-items-center justify-content-center">
                  <span class="ion-ios-play"></span>
                </div>
                <div class="heading-title ml-5">
                  <span>Easy steps for renting a car</span>
                </div>


              </a>
            </div>
          </div>
        </div>
      </div>
      <br><br><br><br><br><br>

    </div>

    <section class="ftco-section ftco-about" >
      <div class="container">
        <div class="row no-gutters">
          <div class="hero-wrap ftco-degree-bg" >
          </div>
          <div class="col-md-6 wrap-about ftco-animate" >
            <div class="heading-section heading-section-white pl-md-5"><br>
              <span class="subheading">About us</span>
              <h2 class="mb-4">Welcome to Carbook</h2>

              <p>A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.</p>
              <p>On her way she met a copy. The copy warned the Little Blind Text, that where it came from it would have been rewritten a thousand times and everything that was left from its origin would be the word "and" and the Little Blind Text should turn around and return to its own, safe country. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.</p>
              
            </div>
          </div>
        </div>
      </div>
      <br><br><br><br><br><br>
    </section>

 







<?php include 'footermain.php';?>
